from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import sqlite3
import hashlib
from jose import jwt
from passlib.context import CryptContext
import os
from contextlib import contextmanager

# Initialize FastAPI app
app = FastAPI(title="Todo List API", description="FastAPI backend for Todo List application")

# CORS middleware for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security setup
security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"

# Database path
DATABASE_PATH = "db.sqlite3"

# Pydantic models
class TaskBase(BaseModel):
    title: str
    description: Optional[str] = ""
    priority: str = "medium"
    due_date: Optional[datetime] = None
    category: Optional[str] = "general"
    tags: Optional[str] = ""

class TaskCreate(TaskBase):
    pass

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    completed: Optional[bool] = None
    due_date: Optional[datetime] = None
    category: Optional[str] = None
    tags: Optional[str] = None

class Task(TaskBase):
    id: int
    completed: bool
    created_at: datetime
    updated_at: datetime
    user_id: int
    is_overdue: bool

class UserCreate(BaseModel):
    username: str
    password: str
    email: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    id: int
    username: str
    email: Optional[str] = None

# Database helper functions
@contextmanager
def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def create_token(data: dict):
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return user_id
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_user_by_username(username: str):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM auth_user WHERE username = ?", (username,))
        return cursor.fetchone()

def is_task_overdue(due_date: str, completed: bool) -> bool:
    if due_date and not completed:
        try:
            # Handle both timezone-aware and naive datetime strings
            if due_date.endswith('Z'):
                due_datetime = datetime.fromisoformat(due_date.replace('Z', '+00:00'))
            else:
                due_datetime = datetime.fromisoformat(due_date)
            
            # Make both datetimes timezone-naive for comparison
            if due_datetime.tzinfo is not None:
                due_datetime = due_datetime.replace(tzinfo=None)
            
            return due_datetime < datetime.now()
        except (ValueError, AttributeError):
            # If there's any issue parsing the date, consider it not overdue
            return False
    return False

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Todo List FastAPI Backend", "status": "running"}

@app.post("/auth/register", response_model=dict)
async def register(user_data: UserCreate):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Check if user exists
        cursor.execute("SELECT id FROM auth_user WHERE username = ?", (user_data.username,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="Username already registered")
        
        # Create user (simplified - in production use Django's user model structure)
        hashed_password = hash_password(user_data.password)
        cursor.execute("""
            INSERT INTO auth_user (username, first_name, last_name, email, password, is_active, is_staff, is_superuser, date_joined)
            VALUES (?, ?, ?, ?, ?, 1, 0, 0, ?)
        """, (user_data.username, "", "", user_data.email or "", hashed_password, datetime.now().isoformat()))
        
        conn.commit()
        return {"message": "User created successfully"}

@app.post("/auth/login", response_model=Token)
async def login(user_data: UserLogin):
    user = get_user_by_username(user_data.username)
    if not user or not verify_password(user_data.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token_data = {"user_id": user["id"], "username": user["username"]}
    access_token = create_token(token_data)
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/tasks", response_model=List[Task])
async def get_tasks(
    user_id: int = Depends(verify_token),
    search: Optional[str] = None,
    category: Optional[str] = None,
    priority: Optional[str] = None,
    completed: Optional[bool] = None,
    sort_by: Optional[str] = "created_at",
    sort_order: Optional[str] = "desc"
):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Build dynamic query
        query = "SELECT * FROM todos_task WHERE user_id = ?"
        params = [user_id]
        
        if search:
            query += " AND (title LIKE ? OR description LIKE ?)"
            search_term = f"%{search}%"
            params.extend([search_term, search_term])
        
        if category:
            query += " AND category = ?"
            params.append(category)
            
        if priority:
            query += " AND priority = ?"
            params.append(priority)
            
        if completed is not None:
            query += " AND completed = ?"
            params.append(1 if completed else 0)
        
        # Add sorting
        valid_sort_fields = ["created_at", "updated_at", "title", "priority", "due_date"]
        if sort_by in valid_sort_fields:
            query += f" ORDER BY {sort_by}"
            if sort_order.lower() == "desc":
                query += " DESC"
            else:
                query += " ASC"
        else:
            query += " ORDER BY created_at DESC"
        
        cursor.execute(query, params)
        
        tasks = []
        for row in cursor.fetchall():
            task_dict = dict(row)
            # Handle missing columns gracefully
            if "category" not in task_dict:
                task_dict["category"] = "general"
            if "tags" not in task_dict:
                task_dict["tags"] = ""
                
            task_dict["is_overdue"] = is_task_overdue(task_dict["due_date"], task_dict["completed"])
            task_dict["created_at"] = datetime.fromisoformat(task_dict["created_at"])
            task_dict["updated_at"] = datetime.fromisoformat(task_dict["updated_at"])
            if task_dict["due_date"]:
                task_dict["due_date"] = datetime.fromisoformat(task_dict["due_date"].replace('Z', '+00:00'))
            tasks.append(Task(**task_dict))
        
        return tasks

@app.post("/tasks", response_model=dict)
async def create_task(task_data: TaskCreate, user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        
        cursor.execute("""
            INSERT INTO todos_task (title, description, priority, completed, due_date, category, tags, created_at, updated_at, user_id)
            VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?)
        """, (
            task_data.title, 
            task_data.description, 
            task_data.priority,
            task_data.due_date.isoformat() if task_data.due_date else None,
            task_data.category or "general",
            task_data.tags or "",
            now, 
            now, 
            user_id
        ))
        
        conn.commit()
        task_id = cursor.lastrowid
        
        return {"message": "Task created successfully", "task_id": task_id}

@app.get("/tasks/{task_id}", response_model=Task)
async def get_single_task(task_id: int, user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM todos_task WHERE id = ? AND user_id = ?", (task_id, user_id))
        row = cursor.fetchone()
        
        if not row:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task_dict = dict(row)
        # Handle missing columns gracefully
        if "category" not in task_dict:
            task_dict["category"] = "general"
        if "tags" not in task_dict:
            task_dict["tags"] = ""
            
        task_dict["is_overdue"] = is_task_overdue(task_dict["due_date"], task_dict["completed"])
        task_dict["created_at"] = datetime.fromisoformat(task_dict["created_at"])
        task_dict["updated_at"] = datetime.fromisoformat(task_dict["updated_at"])
        if task_dict["due_date"]:
            task_dict["due_date"] = datetime.fromisoformat(task_dict["due_date"].replace('Z', '+00:00'))
        
        return Task(**task_dict)

@app.put("/tasks/{task_id}", response_model=dict)
async def update_task(task_id: int, task_data: TaskUpdate, user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Check if task exists and belongs to user
        cursor.execute("SELECT id FROM todos_task WHERE id = ? AND user_id = ?", (task_id, user_id))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Build update query dynamically
        update_fields = []
        values = []
        
        for field, value in task_data.dict(exclude_unset=True).items():
            if field == "due_date" and value:
                values.append(value.isoformat())
            else:
                values.append(value)
            update_fields.append(f"{field} = ?")
        
        if update_fields:
            values.extend([datetime.now().isoformat(), task_id, user_id])
            query = f"UPDATE todos_task SET {', '.join(update_fields)}, updated_at = ? WHERE id = ? AND user_id = ?"
            cursor.execute(query, values)
            conn.commit()
        
        return {"message": "Task updated successfully"}

@app.delete("/tasks/{task_id}", response_model=dict)
async def delete_task(task_id: int, user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM todos_task WHERE id = ? AND user_id = ?", (task_id, user_id))
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Task not found")
        
        conn.commit()
        return {"message": "Task deleted successfully"}

class BulkOperationRequest(BaseModel):
    operation: str
    task_ids: List[int]

@app.post("/tasks/bulk-operations", response_model=dict)
async def bulk_task_operations(
    request: BulkOperationRequest,
    user_id: int = Depends(verify_token)
):
    task_ids = request.task_ids
    operation = request.operation
    
    if not task_ids:
        raise HTTPException(status_code=400, detail="No task IDs provided")
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Verify all tasks belong to the user
        placeholders = ','.join(['?'] * len(task_ids))
        cursor.execute(f"SELECT id FROM todos_task WHERE id IN ({placeholders}) AND user_id = ?", 
                      task_ids + [user_id])
        valid_tasks = [row[0] for row in cursor.fetchall()]
        
        if len(valid_tasks) != len(task_ids):
            raise HTTPException(status_code=404, detail="Some tasks not found")
        
        if operation == "complete":
            cursor.execute(f"UPDATE todos_task SET completed = 1, updated_at = ? WHERE id IN ({placeholders})", 
                          [datetime.now().isoformat()] + task_ids)
            message = f"Marked {len(task_ids)} tasks as completed"
        elif operation == "incomplete":
            cursor.execute(f"UPDATE todos_task SET completed = 0, updated_at = ? WHERE id IN ({placeholders})", 
                          [datetime.now().isoformat()] + task_ids)
            message = f"Marked {len(task_ids)} tasks as incomplete"
        elif operation == "delete":
            cursor.execute(f"DELETE FROM todos_task WHERE id IN ({placeholders})", task_ids)
            message = f"Deleted {len(task_ids)} tasks"
        else:
            raise HTTPException(status_code=400, detail="Invalid operation")
        
        conn.commit()
        return {"message": message, "affected_tasks": len(task_ids)}

@app.get("/user/profile", response_model=User)
async def get_user_profile(user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, email FROM auth_user WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return User(**dict(user))

@app.get("/tasks/stats", response_model=dict)
async def get_task_stats(user_id: int = Depends(verify_token)):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Get task statistics
        cursor.execute("SELECT COUNT(*) FROM todos_task WHERE user_id = ?", (user_id,))
        total_tasks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM todos_task WHERE user_id = ? AND completed = 1", (user_id,))
        completed_tasks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM todos_task WHERE user_id = ? AND completed = 0", (user_id,))
        pending_tasks = cursor.fetchone()[0]
        
        # Get overdue tasks
        cursor.execute("""
            SELECT COUNT(*) FROM todos_task 
            WHERE user_id = ? AND completed = 0 AND due_date IS NOT NULL AND due_date < ?
        """, (user_id, datetime.now().isoformat()))
        overdue_tasks = cursor.fetchone()[0]
        
        return {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "pending_tasks": pending_tasks,
            "overdue_tasks": overdue_tasks,
            "completion_rate": round((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0, 2)
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
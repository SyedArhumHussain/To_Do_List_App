from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from .models import Task
from .forms import TaskForm

@login_required
def task_list(request):
    search_query = request.GET.get('search', '')
    filter_priority = request.GET.get('priority', '')
    filter_status = request.GET.get('status', '')
    
    tasks = Task.objects.filter(user=request.user)
    
    if search_query:
        tasks = tasks.filter(
            Q(title__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    if filter_priority:
        tasks = tasks.filter(priority=filter_priority)
    
    if filter_status == 'completed':
        tasks = tasks.filter(completed=True)
    elif filter_status == 'pending':
        tasks = tasks.filter(completed=False)
    elif filter_status == 'overdue':
        tasks = tasks.filter(due_date__lt=timezone.now(), completed=False)
    
    # Order by priority and due date
    priority_order = ['urgent', 'high', 'medium', 'low']
    tasks = sorted(tasks, key=lambda x: (
        x.completed,
        priority_order.index(x.priority) if x.priority in priority_order else 999,
        x.due_date if x.due_date else timezone.now() + timezone.timedelta(days=365)
    ))
    
    context = {
        'tasks': tasks,
        'search_query': search_query,
        'filter_priority': filter_priority,
        'filter_status': filter_status,
        'priority_choices': Task.PRIORITY_CHOICES,
    }
    return render(request, 'todos/task_list.html', context)

@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            messages.success(request, 'Task created successfully!')
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'todos/task_form.html', {'form': form, 'title': 'Create Task'})

@login_required
def task_update(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, 'Task updated successfully!')
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'todos/task_form.html', {'form': form, 'title': 'Update Task', 'task': task})

@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Task deleted successfully!')
        return redirect('task_list')
    return render(request, 'todos/task_confirm_delete.html', {'task': task})

@login_required
def task_toggle_complete(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    task.completed = not task.completed
    task.save()
    status = 'completed' if task.completed else 'marked as pending'
    messages.success(request, f'Task {status}!')
    return redirect('task_list')

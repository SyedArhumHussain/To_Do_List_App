# Django To-Do List Application

A feature-rich Todo List web application built with Django, featuring user authentication, task prioritization, and due dates.

## Features

### Core Features
- **User Authentication**: Complete registration and login system
- **Task Management**: Full CRUD operations (Create, Read, Update, Delete)
- **Task Prioritization**: 4-level priority system (Low, Medium, High, Urgent)
- **Due Dates**: Optional due date tracking with overdue indicators
- **Task Status**: Mark tasks as complete/incomplete

### User Interface Features
- **Responsive Design**: Bootstrap-based responsive UI
- **Search Functionality**: Search tasks by title and description
- **Advanced Filtering**: Filter by priority, status, and overdue tasks
- **Visual Indicators**: Color-coded priority badges and overdue warnings
- **Clean UI**: Modern, intuitive interface with icons and animations

### Technical Features
- **User Isolation**: Each user sees only their own tasks
- **Database**: SQLite database with proper relationships
- **Security**: CSRF protection and user authentication
- **Admin Interface**: Django admin panel for management

## Getting Started

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Installation

1. **Clone or download this project**
2. **Navigate to project directory**
   ```bash
   cd "To-Do List App"
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run database migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create a superuser (optional)**
   ```bash
   python manage.py createsuperuser
   ```

6. **Start the development server**
   ```bash
   python manage.py runserver
   ```

7. **Access the application**
   - Main application: http://127.0.0.1:8000/
   - Admin panel: http://127.0.0.1:8000/admin/

## Usage

### Getting Started
1. **Register**: Create a new account or login with existing credentials
2. **Create Tasks**: Add new tasks with titles, descriptions, priorities, and due dates
3. **Manage Tasks**: Edit, delete, or mark tasks as complete
4. **Filter & Search**: Use the search and filter options to organize your tasks

### Task Management
- **Creating Tasks**: Click "Add Task" to create new tasks
- **Editing Tasks**: Click the edit icon on any task
- **Completing Tasks**: Click the checkmark to mark as complete/incomplete
- **Deleting Tasks**: Click the trash icon to delete tasks
- **Priority Levels**: 
  - Low (Green)
  - Medium (Yellow)
  - High (Red) 
  - Urgent (Dark)

### Filtering Options
- **Search**: Search by task title or description
- **Priority Filter**: Show tasks of specific priority levels
- **Status Filter**: 
  - All Tasks
  - Pending (incomplete tasks)
  - Completed (finished tasks)
  - Overdue (past due date and incomplete)

## Project Structure

```
To-Do List App/
├── todoproject/          # Main Django project
│   ├── settings.py       # Project settings
│   ├── urls.py          # Main URL configuration
│   └── wsgi.py          # WSGI configuration
├── todos/               # Todo app
│   ├── models.py        # Task model
│   ├── views.py         # Task views
│   ├── forms.py         # Task forms
│   ├── admin.py         # Admin configuration
│   └── urls.py          # Todo URLs
├── accounts/            # Authentication app
│   ├── views.py         # Authentication views
│   └── urls.py          # Authentication URLs
├── templates/           # HTML templates
│   ├── base.html        # Base template
│   ├── registration/    # Auth templates
│   └── todos/           # Task templates
├── static/              # Static files
│   └── css/             # CSS files
├── manage.py            # Django management script
├── requirements.txt     # Python dependencies
└── README.md           # This file
```

## Models

### Task Model
- `title`: Task title (required)
- `description`: Optional task description
- `user`: Foreign key to User (task owner)
- `priority`: Choice field (low, medium, high, urgent)
- `completed`: Boolean field for completion status
- `due_date`: Optional due date with time
- `created_at`: Automatic creation timestamp
- `updated_at`: Automatic update timestamp

## Learning Objectives

This project is perfect for learning Django fundamentals:

1. **Django Basics**: Models, Views, Templates, URLs
2. **User Authentication**: Django's built-in auth system
3. **Database Relations**: Foreign keys and user associations
4. **Forms**: Django forms and validation
5. **Static Files**: CSS and JavaScript management
6. **Template Inheritance**: DRY template design
7. **Bootstrap Integration**: Responsive UI development
8. **CRUD Operations**: Complete data management
9. **Filtering & Search**: Query optimization
10. **Admin Interface**: Django admin customization

## Customization

### Adding New Features
- **Categories**: Add task categories/tags
- **Attachments**: File upload functionality  
- **Notifications**: Email reminders for due dates
- **Collaboration**: Share tasks between users
- **API**: REST API for mobile apps

### Styling
- Modify `static/css/style.css` for custom styling
- Update templates in `templates/` directory
- Customize Bootstrap theme

## Deployment

For production deployment:

1. Set `DEBUG = False` in settings.py
2. Configure proper database (PostgreSQL recommended)
3. Set up static file serving
4. Use environment variables for sensitive settings
5. Deploy to platforms like Heroku, DigitalOcean, or AWS

## Contributing

Feel free to fork this project and submit pull requests for improvements!

## License

This project is open source and available under the MIT License.